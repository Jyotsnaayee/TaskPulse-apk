package com.taskpulse.app

import android.app.TimePickerDialog
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class Palette(val bg: Color, val card: Color, val text: Color, val sub: Color, val track: Color)

private val rainbow = listOf(
    Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFCC00), Color(0xFF34C759),
    Color(0xFF007AFF), Color(0xFF5856D6), Color(0xFFAF52DE)
)

@Composable
private fun palette(dark: Boolean): Palette {
    val spec = tween<Color>(400)
    val bg by animateColorAsState(if (dark) Color(0xFF0E1117) else Color(0xFFF4F5F7), spec, label = "bg")
    val card by animateColorAsState(if (dark) Color(0xFF1B2029) else Color.White, spec, label = "card")
    val text by animateColorAsState(if (dark) Color(0xFFF2F4F8) else Color(0xFF14171C), spec, label = "text")
    val sub by animateColorAsState(if (dark) Color(0xFF9AA4B2) else Color(0xFF5B6472), spec, label = "sub")
    val track by animateColorAsState(if (dark) Color(0xFF2A303B) else Color(0xFFE1E4EA), spec, label = "track")
    return Palette(bg, card, text, sub, track)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskPulseApp(vm: TaskViewModel) {
    val tasks by vm.tasks.collectAsState()
    val daily by vm.daily.collectAsState()
    val darkPref by vm.dark.collectAsState()
    val dark = darkPref ?: androidx.compose.foundation.isSystemInDarkTheme()
    val p = palette(dark)

    var editing by remember { mutableStateOf<Task?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    val stats by vm.stats.collectAsState()
    var showName by remember { mutableStateOf(false) }
    val expanded = remember { mutableStateMapOf<Category, Boolean>() }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            containerColor = p.bg,
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { editing = null; showDialog = true },
                    containerColor = Color(0xFF5856D6), contentColor = Color.White
                ) { Text("+ Add Task", fontWeight = FontWeight.SemiBold) }
            }
        ) { inner ->
            LazyColumn(
                Modifier.fillMaxSize().padding(inner),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Header(p, dark, daily) { vm.setDark(!dark) }
                }
                item { ChartCard(p, daily) }
                Category.values().forEach { cat ->
                    val list = tasks.filter { it.category == cat }
                    val open = expanded[cat] ?: true
                    item(key = "hdr_${cat.name}") {
                        SectionHeader(p, cat, daily, open) { expanded[cat] = !open }
                    }
                    if (open) {
                        if (list.isEmpty()) item(key = "empty_${cat.name}") {
                            Text("No tasks yet", color = p.sub, modifier = Modifier.padding(start = 4.dp))
                        }
                        items(list.size, key = { list[it].id }) { i ->
                            val t = list[i]
                            TaskRow(p, t, { vm.complete(t.id) }) { editing = t; showDialog = true }
                        }
                    }
                }
                item { StatusCard(p, stats) { showName = true } }
                item {
                    OutlinedButton(
                        onClick = { showReset = true },
                        enabled = tasks.isNotEmpty() || daily.totalCreated > 0,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) { Text("Reset Day", color = if (tasks.isNotEmpty() || daily.totalCreated > 0) Color(0xFFFF3B30) else p.sub) }
                }
            }
        }

        if (showDialog) {
            TaskDialog(
                initial = editing,
                onDismiss = { showDialog = false },
                onSave = { vm.save(it); showDialog = false },
                onDelete = { id -> vm.delete(id); showDialog = false }
            )
        }
        if (showName) {
            var n by remember { mutableStateOf(stats.name) }
            AlertDialog(
                onDismissRequest = { showName = false },
                title = { Text("Your name") },
                text = { OutlinedTextField(n, { n = it }, singleLine = true) },
                confirmButton = { TextButton(onClick = { vm.setName(n); showName = false }) { Text("Save") } },
                dismissButton = { TextButton(onClick = { showName = false }) { Text("Cancel") } }
            )
        }
        if (showReset) {
            AlertDialog(
                onDismissRequest = { showReset = false },
                title = { Text("Reset day?") },
                text = { Text("This clears all tasks and cancels their reminders. Progress returns to 0%.") },
                confirmButton = {
                    TextButton(onClick = { vm.resetDay(); showReset = false }) { Text("Reset", color = Color(0xFFFF3B30)) }
                },
                dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun Header(p: Palette, dark: Boolean, daily: Daily, onToggleTheme: () -> Unit) {
    val total = daily.totalCreated
    val done = daily.totalDone
    val target = if (total == 0) 0f else done.toFloat() / total
    val progress by animateFloatAsState(target, tween(600), label = "progress")

    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.logo_mark), contentDescription = "TaskPulse logo",
                colorFilter = ColorFilter.tint(p.text), modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text("TaskPulse", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(
                onClick = onToggleTheme,
                modifier = Modifier.semantics { contentDescription = "Switch to ${if (dark) "light" else "dark"} theme" }
            ) { Text(if (dark) "☀" else "🌙", fontSize = 24.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            RainbowBar(progress, dark, p.track, Modifier.weight(1f).height(16.dp))
            Spacer(Modifier.width(12.dp))
            Text("${(progress * 100).toInt()}%", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Text("$done of $total tasks done", color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun RainbowBar(fraction: Float, dark: Boolean, track: Color, modifier: Modifier) {
    Canvas(modifier.semantics { contentDescription = "Progress ${(fraction * 100).toInt()} percent" }) {
        val r = CornerRadius(size.height / 2)
        drawRoundRect(track, cornerRadius = r)
        val w = size.width * fraction
        if (w > 0f) {
            val brush = Brush.horizontalGradient(rainbow, startX = 0f, endX = size.width)
            if (dark) clipRect(0f, -12f, w, size.height + 12f) {
                drawRoundRect(brush, Offset(0f, -4f), Size(size.width, size.height + 8f), r, alpha = 0.25f)
            }
            clipRect(0f, 0f, w, size.height) {
                drawRoundRect(brush, cornerRadius = r)
            }
        }
    }
}

@Composable
private fun SectionHeader(p: Palette, cat: Category, daily: Daily, open: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(cat.label, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        Text("${daily.done[cat] ?: 0}/${daily.created[cat] ?: 0}", color = p.sub)
        Text(if (open) "  ▾" else "  ▸", color = p.sub)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TaskRow(p: Palette, t: Task, onToggle: () -> Unit, onEdit: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = p.card),
        elevation = CardDefaults.cardElevation(2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onToggle, onLongClick = onEdit)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = t.done, onCheckedChange = { onToggle() },
                modifier = Modifier.semantics { contentDescription = "Mark ${t.title} complete" }
            )
            Column(Modifier.weight(1f).alpha(if (t.done) 0.5f else 1f)) {
                Text(
                    t.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null
                )
                if (t.notes.isNotBlank()) Text(t.notes, color = p.sub, fontSize = 13.sp, maxLines = 2)
                if (t.hasReminder) Text("⏰ ${t.reminderText()}", color = p.sub, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TaskDialog(initial: Task?, onDismiss: () -> Unit, onSave: (Task) -> Unit, onDelete: (Long) -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var cat by remember { mutableStateOf(initial?.category ?: Category.IMPORTANT) }
    var hour by remember { mutableStateOf(initial?.reminderHour) }
    var minute by remember { mutableStateOf(initial?.reminderMinute) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New task" else "Edit task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Task title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Category.values().forEach { c ->
                        FilterChip(
                            selected = cat == c, onClick = { cat = c },
                            label = { Text(c.shortLabel, fontSize = 12.sp, maxLines = 1) }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        TimePickerDialog(ctx, { _, h, m -> hour = h; minute = m }, hour ?: 9, minute ?: 0, true).show()
                    }) {
                        Text(if (hour != null && minute != null) "⏰ %02d:%02d".format(hour, minute) else "⏰ Set reminder")
                    }
                    if (hour != null) TextButton(onClick = { hour = null; minute = null }) { Text("Clear") }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    onSave(
                        Task(
                            id = initial?.id ?: System.currentTimeMillis(),
                            title = title.trim(), notes = notes.trim(), category = cat,
                            done = initial?.done ?: false, reminderHour = hour, reminderMinute = minute
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (initial != null) TextButton(onClick = { onDelete(initial.id) }) { Text("Delete", color = Color(0xFFFF3B30)) }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}


private val green = Color(0xFF34C759)
private val red = Color(0xFFFF3B30)

@Composable
private fun ChartCard(p: Palette, daily: Daily) {
    fun doneOf(c: Category) = daily.done[c] ?: 0
    fun leftOf(c: Category) = ((daily.created[c] ?: 0) - doneOf(c)).coerceAtLeast(0)
    val maxCount = maxOf(1, Category.values().maxOf { maxOf(doneOf(it), leftOf(it)) })
    Card(
        colors = CardDefaults.cardColors(containerColor = p.card),
        shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Today's work", color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                Category.values().forEach { c ->
                    val done = doneOf(c)
                    val left = leftOf(c)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                            Bar(done, maxCount, green, p)
                            Bar(left, maxCount, red, p)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(c.shortLabel, color = p.sub, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Legend(green, "Complete", p); Legend(red, "Incomplete", p)
            }
        }
    }
}

@Composable
private fun Bar(count: Int, max: Int, color: Color, p: Palette) {
    val h by animateDpAsState((count.toFloat() / max * 110f).dp.coerceAtLeast(3.dp), tween(500), label = "bar")
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
        Text("$count", color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        Box(
            Modifier.width(28.dp).height(h).clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)).background(color)
                .semantics { contentDescription = "$count tasks" }
        )
    }
}

@Composable
private fun Legend(color: Color, label: String, p: Palette) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, color = p.sub, fontSize = 12.sp)
    }
}

@Composable
private fun StatusCard(p: Palette, s: Stats, onEditName: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = p.card),
        shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onEditName), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(rainbow)),
                    contentAlignment = Alignment.Center
                ) { Text(s.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(s.name, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text("Status · tap to edit name", color = p.sub, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(p, "Active", "${s.activeDays}", "days", Modifier.weight(1f))
                StatTile(p, "Tasks written", "${s.totalWritten}", "total", Modifier.weight(1f))
                StatTile(p, "Completed", "${s.totalCompleted}", "total", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun StatTile(p: Palette, label: String, value: String, unit: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(p.track).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = p.text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text(unit, color = p.sub, fontSize = 11.sp)
        Spacer(Modifier.height(2.dp))
        Text(label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
