package com.taskpulse.app

enum class Category(val label: String, val shortLabel: String) {
    IMPORTANT("Important Work", "Important"),
    LESS("Less Important Work", "Less Important"),
    DAILY("Daily Work", "Daily")
}

data class Task(
    val id: Long,
    val title: String,
    val notes: String = "",
    val category: Category = Category.IMPORTANT,
    val done: Boolean = false,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null
) {
    val hasReminder get() = reminderHour != null && reminderMinute != null
    fun reminderText() = if (hasReminder) "%02d:%02d".format(reminderHour, reminderMinute) else ""
}
