package com.taskpulse.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Daily(val created: Map<Category, Int>, val done: Map<Category, Int>) {
    val totalCreated get() = created.values.sum()
    val totalDone get() = done.values.sum()
}

data class Stats(val name: String, val activeDays: Int, val totalWritten: Int, val totalCompleted: Int)

class TaskViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val prefs = app.getSharedPreferences("taskpulse", 0)

    private val _tasks = MutableStateFlow(load())
    val tasks: StateFlow<List<Task>> = _tasks.asStateFlow()

    // Guards against double counting: ids already completed and waiting to be removed
    private val pending = mutableSetOf<Long>()

    private val _daily = MutableStateFlow(loadDaily())
    val daily: StateFlow<Daily> = _daily.asStateFlow()

    // Today's per-category totals; survive task deletion so the progress bar stays accurate
    private fun loadDaily(): Daily {
        val today = LocalDate.now().toString()
        if (prefs.getString("dDate", null) != today) {
            val e = prefs.edit().putString("dDate", today)
            Category.values().forEach { c ->
                val l = _tasks.value.filter { it.category == c }
                e.putInt("c_" + c.name, l.size).putInt("d_" + c.name, l.count { it.done })
            }
            e.apply()
        }
        return Daily(
            Category.values().associateWith { prefs.getInt("c_" + it.name, 0) },
            Category.values().associateWith { prefs.getInt("d_" + it.name, 0) }
        )
    }

    private fun adjust(c: Category, created: Int, done: Int) {
        loadDaily()
        prefs.edit()
            .putInt("c_" + c.name, (prefs.getInt("c_" + c.name, 0) + created).coerceAtLeast(0))
            .putInt("d_" + c.name, (prefs.getInt("d_" + c.name, 0) + done).coerceAtLeast(0))
            .apply()
        _daily.value = loadDaily()
    }

    // null = follow system until the user picks a theme
    private val _dark = MutableStateFlow(
        if (prefs.contains("dark")) prefs.getBoolean("dark", false) else null
    )
    val dark: StateFlow<Boolean?> = _dark.asStateFlow()

    private val _stats = MutableStateFlow(loadStats())
    val stats: StateFlow<Stats> = _stats.asStateFlow()

    init { recordActiveDay() }

    private fun loadStats() = Stats(
        name = prefs.getString("name", "You") ?: "You",
        activeDays = (prefs.getStringSet("activeDays", emptySet()) ?: emptySet()).size,
        totalWritten = prefs.getInt("totalWritten", 0),
        totalCompleted = prefs.getInt("totalCompleted", 0)
    )

    // One entry per calendar day the app was opened since install
    private fun recordActiveDay() {
        val days = (prefs.getStringSet("activeDays", emptySet()) ?: emptySet()).toMutableSet()
        if (days.add(LocalDate.now().toString())) prefs.edit().putStringSet("activeDays", days).apply()
        _stats.value = loadStats()
    }

    fun setName(name: String) {
        prefs.edit().putString("name", name.trim().ifEmpty { "You" }).apply()
        _stats.value = loadStats()
    }

    private fun bump(key: String, by: Int) {
        prefs.edit().putInt(key, (prefs.getInt(key, 0) + by).coerceAtLeast(0)).apply()
        _stats.value = loadStats()
    }

    fun setDark(value: Boolean) {
        _dark.value = value
        prefs.edit().putBoolean("dark", value).apply()
    }

    fun save(task: Task) {
        val list = _tasks.value
        val existing = list.firstOrNull { it.id == task.id }
        if (existing == null) {
            bump("totalWritten", 1); adjust(task.category, 1, 0)
        } else if (existing.category != task.category) {
            val d = if (existing.done) 1 else 0
            adjust(existing.category, -1, -d); adjust(task.category, 1, d)
        }
        _tasks.value = if (list.any { it.id == task.id })
            list.map { if (it.id == task.id) task else it } else list + task
        persist()
        ReminderScheduler.cancel(ctx, task.id)
        if (!task.done) ReminderScheduler.schedule(ctx, task)
    }

    // Completing is one-way: strike through, count once, then remove after a short delay
    fun complete(id: Long) {
        val t = _tasks.value.firstOrNull { it.id == id } ?: return
        if (t.done || !pending.add(id)) return
        bump("totalCompleted", 1)
        adjust(t.category, 0, 1)
        save(t.copy(done = true))
        viewModelScope.launch {
            delay(1000)
            pending.remove(id)
            removeTask(id)
        }
    }

    fun delete(id: Long) {
        val t = _tasks.value.firstOrNull { it.id == id } ?: return
        if (!t.done) adjust(t.category, -1, 0) // keep completion percentage fair
        removeTask(id)
    }

    private fun removeTask(id: Long) {
        ReminderScheduler.cancel(ctx, id)
        _tasks.value = _tasks.value.filterNot { it.id == id }
        persist()
    }

    fun resetDay() {
        _tasks.value.forEach { ReminderScheduler.cancel(ctx, it.id) }
        _tasks.value = emptyList()
        pending.clear()
        persist()
        loadDaily()
        val e = prefs.edit()
        Category.values().forEach { e.putInt("c_" + it.name, 0).putInt("d_" + it.name, 0) }
        e.apply()
        _daily.value = loadDaily()
    }

    private fun persist() {
        val arr = JSONArray()
        _tasks.value.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("notes", it.notes)
                put("cat", it.category.name); put("done", it.done)
                put("h", it.reminderHour ?: -1); put("m", it.reminderMinute ?: -1)
            })
        }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }

    private fun load(): List<Task> {
        val raw = prefs.getString("tasks", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Task(
                    id = o.getLong("id"), title = o.getString("title"),
                    notes = o.optString("notes"),
                    category = Category.valueOf(o.getString("cat")),
                    done = o.getBoolean("done"),
                    reminderHour = o.getInt("h").takeIf { h -> h >= 0 },
                    reminderMinute = o.getInt("m").takeIf { m -> m >= 0 }
                )
            }
        } catch (e: Exception) { emptyList() }
    }
}
