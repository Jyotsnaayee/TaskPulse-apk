# TaskPulse (Android)
Kotlin + Jetpack Compose. Open this folder in Android Studio (Koala or newer),
let Gradle sync, then Run. Min SDK 26, target 35.
